MVP Painting — Rescue Baseline
==============================

Two ways to get back online fast:

OPTION A — Static publish (quickest)
------------------------------------
1) In Netlify, set:
   - Publish directory: public
   - Build command: npm run build:css
   Or use the included netlify.static.toml
2) Ensure your HTML lives in /public (already included).
3) Add your images under /public/assets/images.
4) If you can download a prior Netlify deploy, copy its /assets/css/style.css and /assets/css/custom.css into /public/assets/css/ here.
5) Commit & deploy.

OPTION B — Full Vite build (future-proof)
-----------------------------------------
1) In Netlify, set:
   - Publish directory: dist
   - Build command: npm run build
   Or use the included netlify.vite.toml
2) Keep index.html at project root (Vite will output to /dist)
3) Static files can go in /public

Configs included
----------------
- tailwind.config.js → content scans ./public/**/*.html and ./src/**/* to keep your utilities.
- postcss.config.js → tailwindcss + autoprefixer.
- src/input.css → @tailwind base/components/utilities.
- public/assets/js/hero-rotator.js → simple slide rotator to match your HTML.
- public/assets/css/custom.css → placeholder to avoid 404; replace with your real file when you retrieve it.

Note
----
This bundle doesn't include your original custom CSS (style.css) because it wasn't uploaded.
If you download an older Netlify deploy ZIP, grab the built CSS/JS and drop them into /public/assets/* here.
