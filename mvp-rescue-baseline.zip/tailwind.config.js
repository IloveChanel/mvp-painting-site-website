/** Minimal Tailwind config to (re)build your utilities.
 *  Make sure your HTML lives in /public so classes aren't purged.
 */
module.exports = {
  content: ["./public/**/*.html", "./src/**/*.{js,ts}"],
  theme: { extend: {} },
  plugins: [],
};
